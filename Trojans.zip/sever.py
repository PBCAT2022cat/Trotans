

import socket,threading

        
def sendd():
    global hello
    try:
        a = input('cmd > ')+'\n'
        if a == 'exit\n':
            hello = False
        sock.send(a.encode())
        num = sock.recv(1024).decode()
        num = int(num)
        num *= 8
        num += 2048
        a = sock.recv(num).decode()
        print(a)
        
    except Exception as rr:
        print(rr)

hello = True
print(socket.gethostname())
host = input('ip:')
post = 12345
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)#定义套接字（类型）
s.bind((host,post))#监听
s.listen(1)
sock,addr = s.accept()
try:
    while hello:
        sendd()
        
except Exception as r:
    print(r)
    
hello = False
s.close()
sock.close()
